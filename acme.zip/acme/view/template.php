<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title>Acme Template</title>
    </head>

    <body id="background">
        <div id="wrap">
            
             <?php include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/header.php'; ?>
        
                
        
   
            <main>
        <h1><b> Content Title Here</b></h1>
            </main>
        
        <footer>
            <?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
        </footer>
    </div>