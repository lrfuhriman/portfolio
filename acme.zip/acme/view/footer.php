                <p>ACME, All rights reserved.<br>
                    All images used are believed to be in <q>"Fair Use"</q>.
                     Please notify the author if any are not and they will be removed. <br>
                    Last Updated: 20 January, 2018</p>
                
            
