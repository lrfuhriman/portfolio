<?php
if($_SESSION['clientData']['clientLevel'] < 2){
 header('location: /acme/');
 exit;
}
?>

?>
<!DOCTYPE html>
<?php
if ($_SESSION['clientData']['clientLevel'] < 2) {
 header('location: /acme/');
 exit;
}
?>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title><?php if(isset($prodInfo['invName'])){ echo "Delete $prodInfo[invName]";} ?>Product Site </title>
    </head>

    <body id="background">
        <div id="wrap">
            
             <?php include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/header.php'; ?>
        
                
        
   
            <main>
        <h1><b><?php if(isset($prodInfo['invName'])){ echo "Delete $prodInfo[invName]";} ?> Products</b></h1>
        <p>Confirm Product Deletion. The delete is permanent.</p>
        <?php
            if (isset($message)){
                echo $message;
            }
            ?>
        <form method="post" action="/acme/products/">
 <fieldset id="productTable">

  <label for="invName">Product Name</label>
  <input type="text" readonly name="invName" id="invName" <?php if(isset($prodInfo['invName'])) {echo "value='$prodInfo[invName]'"; }?>>

  <label for="invDescription">Product Description</label>
  <textarea name="invDescription" readonly id="invDescription"><?php if(isset($prodInfo['invDescription'])) {echo $prodInfo['invDescription']; } ?></textarea>

  <label>&nbsp;</label> 
  <input type="submit" class="regbtn" name="submit" value="Delete Product">

  <input type="hidden" name="action" value="deleteProd">
  <input type="hidden" name="invId" value="<?php if(isset($prodInfo['invId'])){ echo $prodInfo['invId'];} ?>">

 </fieldset>
</form>
            </main>
        
        <footer>
            <?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
        </footer>
    </div>