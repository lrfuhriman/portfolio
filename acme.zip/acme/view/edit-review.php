<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title><?php if(isset($prodInfo['invName'])){ echo "Modify $prodInfo[invName] ";} elseif(isset($invName)) { echo $invName; }?>Product Site </title>
    </head>
<body id="background">
        <div id="wrap">

<?php include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/header.php'; ?>

<main>


  <h1>Update Review</h1>
    <?php
            if (isset($message)){
                echo $message;
            }
            ?>
  <form method="post" action="/acme/reviews/index.php" class="stacked-form">
    <label for="reviewText">Review Content</label>
    <textarea cols="50" id="reviewText" name="reviewText" required rows="5"><?php if(isset($reviewDetails['reviewText'])){echo $reviewDetails['reviewText'];} ?></textarea>
  <br>
  <input class="button" id="formButton" name="submit" type="submit" value="Save Edits">
  <input name="action" type="hidden" value="process-edit-review">
  <input name="reviewId" type="hidden" value="<?php echo $reviewDetails['reviewId']; ?>">
 
</form>

</main>
            
            <footer>

<?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
            </footer>

</div>
</body>
</html>