<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title>Registration</title>
    </head>

    <body id="background">
        <div id="wrap">

            <main>
        <h1><b>Registration</b></h1>
        
        <?php
            if (isset($message)) {
                echo $message;
}
                ?>
        
        <form method="post" action="/acme/accounts/index.php">
            <fieldset>
                First Name: <br>
                <input name="clientFirstname" id="clientFirstname" required=""><br>
                Last Name: <br>
                <input type="text" name="clientLastname" value="" required=""  required><br>
                Email: <br>
                <input type="email" name="clientEmail" value="" required="" placeholder="Enter a valid Email address" required=""><br>
                Password: <br>
                <span>Password can be max of 15 characters and can only have letters (capital or lowercase) and can have any number.</span>
                <input type="password" name="clientPassword" value="" required="" 
                       pattern="[A-Za-z0-9_]{3,15}"><br>
                <input class="button" type="submit" id="regbtn" value="register">
                <input type="hidden" name="action" value="register">
                
            </fieldset>
        </form>
            </main>
            
        </div>
    