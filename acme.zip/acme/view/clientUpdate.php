<?php 
       if (isset($_SESSION['loggedin'])!= TRUE) {
       header('location: /acme/');
       }
$firstName = $_SESSION['clientData']['clientFirstname'];
$lastName = $_SESSION['clientData']['clientLastname'];
$email = $_SESSION['clientData']['clientEmail'];
$customerId = $_SESSION['clientData']['clientId'];
 ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title><?php if(isset($clientData['clientName'])){ echo "Modify $clientData[clientName] ";} elseif(isset($clientName)) { echo $clientName; }?>Client Info </title>
    </head>

    <body id="background">
        <div id="wrap">
            
             <?php include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/header.php'; ?>
        
                
        
   
            <main>
        <h1><b><?php if(isset($clientData['clientName'])){ echo "Modify $clientData[clientName] ";} elseif(isset($clientData)) { echo $clientData; }?> Client Info</b></h1>
        <?php
            if (isset($message)){
                echo $message;
            }
            ?>
        <form action="/acme/accounts/index.php" method="post">
            <fieldset id="productTable" >
                <label for="clientFirstname"> First Name</label>
                <input type="text" name="clientFirstname" id="clientFirstname" required <?php if(isset($firstName)){ echo "value='$firstName'"; } elseif(isset($clientInfo['clientFirstname'])) {echo "value='$clientInfo[clientFirstName]'"; }?>>
                <label for="clientLastname">Last Name</label>
                <input type="text" name="clientLastname" id="clientLastname" required <?php if(isset($lastName)){ echo "value='$lastName'"; } elseif(isset($clientInfo['clientLastname'])) {echo "value='$clientInfo[clientLastName]'"; }?>>
                <label for="clientEmail">Email</label>
                <input type="text" name="clientEmail" id="clientEmail" required <?php if(isset($email)){ echo "value='$email'"; } elseif(isset($clientInfo['clientEmail'])) {echo "value='$clientInfo[clientEmail]'"; }?>>
                
                <input class="button" type="submit" name="submit" value="Update Account">
                
                <input type="hidden" name="action" value="updateAccount">
                <input type="hidden" name="clientId" <?php if(isset($customerId)){ echo "value='$customerId'"; } elseif(isset($clientInfo['clientId'])) {echo "value='$clientInfo[clientId]'"; }?>>
            </fieldset>
                
        </form>
        
        
        <h1><b><?php if(isset($clientData['clientPassword'])){ echo "Modify $clientData[clientPassword] ";} elseif(isset($clientData)) { echo $clientData; }?> Password</b></h1>
        <span>Password must be at least 8 characters and contains at least one number, 1 capital letter and one special character</span>
        <?php
            if (isset($msg)){
                echo $msg;
            }
            ?>
        <form action="/acme/accounts/index.php" method="post">
            <fieldset id="productTable2" >
                <label for="updatePassword"> Password</label>
                <input type="text" name="updatePassword" id="updatePassword" required pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[a-z]).*$">
                
                <input class="button" type="submit" name="submit" value="Update Password">
                
                <input type="hidden" name="action" value="updatePassword">
                <input type="hidden" name="clientId" <?php if(isset($customerId)){ echo "value='$customerId'"; } elseif(isset($clientData)) {echo "value='$clientData'"; }?>>
            </fieldset>
                
        </form>
            </main>
        
        <footer>
            <?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
        </footer>
    </div>
        <?php unset($_SESSION['message']); ?>