<!DOCTYPE html>
<?php
if ($_SESSION['clientData']['clientLevel'] < 2) {
 header('location: /acme/');
 exit;
}
?>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title>Add Category</title>
    </head>

    <body id="background">
        <div id="wrap">
            
             <?php include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/header.php'; ?>
        
                
        
   
            <main>
        <h1> Category</h1>
        <?php if(isset($message)){ echo $message; } ?>
        <form action="/acme/products/index.php" method="post">
            <fieldset>
                <label for="categoryName">Category Name</label><br>
                <input type="text" name="categoryName" id="categoryName" <?php if(isset($categoryName)){echo "value='$categoryName'";} ?> required="" >
                <input id="button" type="submit" value="Add Category">
                <input type="hidden" name="action" value="category">
            </fieldset>
                
        </form>
            </main>
        
        <footer>
            <?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
        </footer>
    </div>