<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title>Acme Registration</title>
    </head>

    <body id="background">
        <div id="wrap">
<?php $ptitle = 'login'; include ($_SERVER ['DOCUMENT_ROOT'] . '/acme/view/header.php'); ?>

            <main>
        <h1><b>Acme Registration</b></h1>
        
        <?php
            if (isset($message)) {
                echo $message;
}
                ?>
        
        <form method="post" action="/acme/accounts/index.php">
            <fieldset>
                First Name: <br>
                <input name="clientFirstname" id="clientFirstname" <?php if(isset($clientFirstname)){echo "value='$clientFirstname'";} ?> required><br>
                Last Name: <br>
                <input type="text" name="clientLastname" value="" required="" <?php if(isset($clientLastname)){echo "value='$clientLastname'";} ?> required><br>
                Email: <br>
                <input type="email" name="clientEmail" value="" required="" placeholder="Enter a valid Email address"<?php if(isset($clientEmail)){echo "value='$clientEmail'";} ?> required><br>
                Password: <br>
                <span>Password must be at least 8 characters and contains at least one number, 1 capital letter and one special character</span>
                <input type="password" name="clientPassword" value="" required="" 
                       pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[a-z]).*$"><br>
                <input class="button" type="submit" id="regbtn" value="register">
                <input type="hidden" name="action" value="register">
                
            </fieldset>
        </form>
            </main>
            <footer>
            <?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
        </footer>
        </div>
    