<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title>Acme Site</title>
    </head>

    <body id="background">
        <div id="wrap">
            
            <?php include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/header.php'; ?>
            <h1><b> Welcome to Acme!</b></h1>
            
            
            <main>
                <div id="dinnerrocket">
                    <ul>
                        <li><h2>Acme Rocket</h2> </li>
                        <li>Quick lighting fuse </li>
                        <li>NHTSA approved seat belts</li>
                        <li>Mobile launch stand included</li>
                    </ul>
                    <a id="iwantit" href="#"><img src="/acme/images/site/iwantit.gif" alt=" I Want It"></a>
                </div>
                <div id="bottom-half">
                    <div id="recipes">
                        <div class="recipes-title">
                            <h3>Featured Recipes </h3>
                            <table>
            <tr>
                <td>
            <img src="/acme/images/recipes/bbqsand.jpg" alt="BBQand">
                </td>
                <td>
            <img src="/acme/images/recipes/potpie.jpg" alt="Potpie">
            </tr>
            <tr>
                <td>
                    <a href= "*">Pulled Roadrunner BBQ </a>
                </td>
                <td>
                    <a href= "#"> Roadrunner Pot Pie </a>
                </td>
            </tr>
            <tr>
                <td>
                    <img src="/acme/images/recipes/soup.jpg" alt="Soup">
                </td>
                <td>
                    <img src="/acme/images/recipes/taco.jpg" alt="Taco">
                </td>
            </tr>
            <tr>
                <td>
                    <a href= "#"> Roadrunner Soup </a>
                </td>
                <td>
                    <a href= "#"> Roadrunner tacos </a>
                </td>
            </tr>
        </table>
                        </div>
                    </div>
        
        
        <div id="arr">
            <h3>Acme Rocket Reviews</h3>
         <ul>
             
            <li><q>"I don't know how i ever caught roadrunners before this." (4/5)</q></li>
            <li><q>"That was fast!" (4/5)</q></li>
            <li><q>"Talk about fast delivery" (5/5)</q></li>
            <li><q>"I didn't even have to pull the meat apart." (4.5/5)</q></li>
            <li><q>"I'm on my thirteenth one. I love these things!" (5/5)</q></li>
         </ul>
        </div>
    </div>
        
        
  
            
</main>
        <footer>
            <?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
        </footer>
        </div>
            
    </body>

</html>

        
    
