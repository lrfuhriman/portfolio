<!DOCTYPE html>
<?php
if ($_SESSION['clientData']['clientLevel'] < 2) {
 header('location: /acme/');
 exit;
}
?>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title>Product Management</title>
    </head>

    <body id="background">
        <div id="wrap">
            
             <?php $ptitle='Login'; include ($_SERVER['DOCUMENT_ROOT'].'/acme/view/header.php');?>
        
                
        
   
            <main>
        <h1><b> Product Management</b></h1>
        <?php
            if (isset($message)){
                echo $message;
            }
            ?>
        <ul>
            <li><a href="http://localhost/acme/products/index.php?action=addcat">Add a New Category</a></li>
            <li><a href="http://localhost/acme/products/index.php?action=addprod">Add a New Product</a></li> 
            <?php
if (isset($message)) {
 echo $message;
} if (isset($prodList)) {
 echo $prodList;
}
?>
        </ul>
            </main>
        
        <footer>
            <?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
        </footer>
    </div>
        <?php unset($_SESSION['message']); ?>

