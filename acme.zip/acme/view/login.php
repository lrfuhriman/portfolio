<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title>Acme Login</title>
    </head>

    <body id="background">
        <div id="wrap">
<?php $ptitle = 'login'; include ($_SERVER ['DOCUMENT_ROOT'] . '/acme/view/header.php'); ?>

            <main>
        <h1><b>Acme Login</b></h1>
        
        <form method="post" action="/acme/accounts/">
            <fieldset>
                Email: <br>
                <input type="email" name="clientEmail" required placeholder="Enter a valid Email address"<?php if(isset($clientEmail)){echo $clientEmail;} ?> ><br>
                Password: <br>
                <span>Password must be at least 8 characters and contains at least one number, 1 capital letter and one special character</span>
                <input type="password" name="clientPassword" required 
                       pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$"><br>
                <input class="button" type="submit" id="regbtn" value="Sign In">
                <input type="hidden" name="action" value="login">
            </fieldset>
        </form>
        
            </main>
            
            <h2>Not a member?</h2>
            <form method="post" action="http://localhost/acme/accounts/index.php?action=registration">
                <input class="button" type="submit" value="Create Account">
            </form>
    
        
        <footer>
            <?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
        </footer>
        </div>
    </body>
</html>
    