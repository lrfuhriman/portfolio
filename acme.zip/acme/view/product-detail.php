<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title><?php echo $type; ?> Products | Acme, Inc.</title>
    </head>

    <body id="background">
        <div id="wrap">
            
             <?php include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/header.php'; ?>
        
        <main>
        <div id="review-banner">
    <p>Take a look at the reviews at the <a href='#bottom'>bottom!</a></p>
  </div>
  <?php if(isset($message)){ echo $message; } ?>
  <?php if(isset($prodDisplay)){ echo $prodDisplay; } ?>
  <hr>
  <?php if(isset($thumbDisplay)){ echo $thumbDisplay; } ?>
  <hr>
  
  <?php
    if (isset($_SESSION['loggedin'])) {
      $first = substr($_SESSION['clientData']['clientFirstname'], 0, 1);
      $last = $_SESSION['clientData']['clientLastname'];
      $screenName = $first . $last;
      $sessionClientDataClientId = $_SESSION['clientData']['clientId'];
      if (isset($reviewFormMessage)) {
        echo $reviewFormMessage;
      }
      echo '<form action="/acme/reviews/index.php" method="post" id="review-form">'."\n";
      echo "<label for='reviewText'>Review this product as $screenName</label>"."\n";
      echo '<br>'."\n";
      echo '<textarea cols="50" id="reviewText" name="reviewText" placeholder="Leave a product review here" required rows="5"></textarea>'."\n";
      echo '<br>'."\n";
      echo '<input class="button" name="submit" type="submit" value="Submit Review">'."\n";
      echo "<input type='hidden' name='clientId' value='$sessionClientDataClientId'>"."\n";
      echo "<input type='hidden' name='invId' value='$invId'>"."\n";
      echo '<input type="hidden" name="action" value="new-review">'."\n";
      echo '</form>'."\n";
    } else {
      echo "<p><a href='/acme/accounts/index.php?action=login'>Login</a> to review this product."."\n";
    }
    echo '<br>';
    echo '<a id="bottom"></a>';
    echo '<h2>Customer Reviews</h2>';
    if (isset($itemReviews)) {
      echo $reviewsDisplay;
    } else {
      echo '<p>This product has not been reviewed yet.</p>'."\n";
    }
?>

            </main>
        
        <footer>
            <?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
        </footer>
    </div>