<?php if(!$_SESSION['loggedin']){
    header ('location: /acme/');
    exit;
}?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta name="HandheldFriendly" content="true">
        <link href="/acme/css/index.css" media="screen" rel="stylesheet" type="text/css">
        <title>Acme.com</title>
    </head>

    <body id="background">
        <div id="wrap">
            
             <?php include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/header.php'; ?>
        
                
        
   
            <main>
                <?php
                $firstName = $_SESSION['clientData']['clientFirstname'];
                $lastName = $_SESSION['clientData']['clientLastname'];
                $email = $_SESSION['clientData']['clientEmail'];
                $level = $_SESSION['clientData']['clientLevel'];
                
                echo "<h1>$firstName $lastName Logged in</h1>";
                    if (isset($_SESSION['message'])){
                        $message = $_SESSION['message'];
                        echo $message;
                    }
                echo    "<ul>
                        <li>First Name: $firstName</li>
                        <li>Last Name: $lastName</li>
                        <li> Email: $email</li>
                    </ul>" ;
                echo '<a href="http://localhost/acme/accounts/index.php?action=clientUpdate">Update account information</a>';
                
                if ($level > 1) {
                    echo "<h2> Use the follwoing link to administer prducts</h2>";
                    echo '<a href="http://localhost/acme/products/index.php?action=product-mgmt">Products</a><br>';
                }
                ?>
                <?php if(isset($reviewList)){ 
                    echo $reviewList; 
                    
                }?>
            </main>
        
        <footer>
            <?php
        include $_SERVER ['DOCUMENT_ROOT'] . '/acme/view/footer.php';
        ?>
        </footer>
    </div>