

        

        <header>
            
<img class="logo" src="/acme/images/site/logo.gif" alt="Acme Logo">
  <div class="folder">
         <img id="file" src="/acme/images/site/account.gif" alt="File Pic">|<?php 
        if(isset($cookieFirstname)) {
            echo "<span>Welcome $cookieFirstname</span>";
        }
    ?>
      
      <?php 
      if (isset($_SESSION['loggedin'])){
          $clientFirstname = $_SESSION['clientData']['clientFirstname'];
          echo "<span><a href='http://localhost/acme/reviews/'>Welcome $clientFirstname</a></span>";
          echo '<a href="http://localhost/acme/accounts/index.php?action=Logout">Logout</a>';
      } else {
          echo '<a href="http://localhost/acme/accounts/index.php?action=signIn">My Account</a>';
      }
      ?>
      
        
  </div> 
        

              
        </header>
        
                <div class="wrapper2">

        <nav>
        <?php echo $navList; ?>
            <!--
<ul>
                <li><a href= "home.php"> Home </a></li>
                <li><a href= "#"> Cannon </a></li>
                <li><a href= "#"> Explosive </a></li>
                <li><a href= "#"> Misc </a></li>
                <li><a href= "#"> Rocket </a></li>
                <li><a href= "#"> Trap </a></li>
            </ul>

-->
        </nav>
                    
            </div>
        
        
        
        
        
